var element = document.querySelector("#greeting");
element.innerText = "Hello, world!";

window.addEventListener('midiin-event:foo-input', function(event) {
  var out=[];
  var text=document.querySelector("#result").innerHTML;
  for(var i=0; i<event.detail.data.length; i++) {
    out.push("0x"+("00"+event.detail.data[i].toString(16)).substr(-2));
  }
  document.querySelector("#result").innerHTML=out.join(" ")+"<br>"+text;
});

var midiout;
window.addEventListener('midioutput-updated:foo-output', function(event) {
  if(event.target.outputIdx!="false") {
    document.addEventListener('keydown', keyDownEvent);
    document.addEventListener('keyup', keyUpEvent);
    midiout=document.querySelector("#foo-output");
    document.getElementById("evy1text").addEventListener("click", evy1text);
    document.getElementById("poke39text").addEventListener("click", poke39text);
  } else {
    document.removeEventListener('keydown', keyDownEvent);
    document.removeEventListener('keyup', keyUpEvent);
    document.getElementById("evy1text").removeEventListener("click", evy1text);
    document.getElementById("poke39text").removeEventListener("click", poke39text);
    midiout="";
  }
});

// for midi output
var c_on=false;
function keyDownEvent(event) {
  if(event.keyCode==67 && c_on===false) {
    c_on=true;
    midiout.sendRawMessage([0x90, 0x45, 0x7f], 0);
  }
}
function keyUpEvent(event) {
  if(event.keyCode==67 && c_on===true) {
    c_on=false;
    midiout.sendRawMessage([0x80, 0x45, 0x7f], 0);
  }
}

// for nsx-1
function evy1text() {
  var text=document.getElementById("text").value;
  var out=document.getElementById("evy1").convertText2SysEx(text);
  sendSysEx2Device(out);
  playTone(text.length);
}
function poke39text() {
  var text=document.getElementById("text").value;
  var out=document.getElementById("poke39").convertText2SysEx(text);
  sendSysEx2Device(out);
  playTone(text.length);
}
function sendSysEx2Device(msg) {
  for(var i=0; i<msg.sysEx.length; i++) {
    midiout.sendRawMessage(msg.sysEx[i], 0);
  }
}
function playTone(count) {
  var interval=400; // (ms)
  var noteNo=69; // A4
  for(var i=1; i<=count; i++) {
    midiout.sendRawMessage([0x90, "0x"+(noteNo+i).toString(16), 0x7f], interval*i);
    midiout.sendRawMessage([0x80, "0x"+(noteNo+i).toString(16), 0x7f], interval*(i+1));
  }  
}

